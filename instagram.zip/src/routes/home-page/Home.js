import React from 'react'
import Actual from '../../components/actual/Actual'
import Header from '../../components/header/Header'
import MyComment from '../../components/my-comment/MyComment'
import Stories from '../../components/story/Stories'
// <Sidebar/>
// import Sidebar from '../../components/sidebar/Sidebar'
import './Home.css'

function Home() {
    return (
        <div className="home">
            <Header />
            <div className="home__container">
                <div className="home__wrapper">
                    <Stories />
                    <Actual />
                </div>
                <MyComment/>
            </div>
        </div>
    )
}

export default Home
