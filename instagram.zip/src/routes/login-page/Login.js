import React from 'react'
import './Login.css'

function Login() {
    return (
        <div className="login">
            <p>salom login</p>
        </div>
    )
}

export default Login
