import './styles/App.css';
import Home from './routes/home-page/Home';
import Login from './routes/login-page/Login';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'

function App() {
  const user = true
  return (
    <Router>
      <div className="App">
        <Switch>
          {
            user ? <Route exact path="/" component={Home} /> : <Login />
          }
        </Switch>
      </div>
    </Router>
  );
}

export default App;
