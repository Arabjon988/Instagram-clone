import React from 'react'
import'../styles-component./Sidebar.css'

function Sidebar() {
    return (
        <div className="sidebar">
            <h3>This is Sidebar</h3>
        </div>
    )
}

export default Sidebar
