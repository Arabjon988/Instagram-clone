import React from 'react'
import '../styles-component/Stories.css'
import StoryData from '../../data/Story-data.json'


function Stories() {
    return (
        <div className="stories">
        {
            StoryData?.map((photo) => (
                <div key={photo.id} className="story-human">

                <img src={photo?.url} alt="" />
                <p>hfjhabfba</p>

                </div>
            ))
        }
        </div>
    )
}

export default Stories
