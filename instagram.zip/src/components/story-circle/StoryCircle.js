import React from 'react'
// import '../styles-component/StoryCircle.css'


function StoryCircle() {
    return (
        <div className="storyCircle">
           <h4>sdkabfkbdjk</h4>
        </div>
    )
}

export default StoryCircle
