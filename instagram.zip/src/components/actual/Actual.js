import React from 'react'
import './Actual.css'

function Actual() {
    return (
        <div className="actual">
            <p>First Pace</p>
            <ul className="actual-collection">
                <li className="actual-item"><h3>Lorem, ipsum dolor.</h3>
                    <p>Lorem ipsum dolor sit amet </p>
                    <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit eveniet porro obcaecati earum ipsam sunt dolore debitis</span>
                </li>
                <li className="actual-item"><h3>Lorem, ipsum dolor.</h3>
                    <p>Lorem ipsum dolor sit amet </p>
                    <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit eveniet porro obcaecati earum ipsam sunt dolore debiti</span>
                </li>
                <li className="actual-item"><h3>Lorem, ipsum dolor.</h3>
                    <p>Lorem ipsum dolor sit amet </p>
                    <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit eveniet porro obcaecati earum ipsam sunt dolore debitis</span>
                </li>

            </ul>
        </div>
    )
}

export default Actual
