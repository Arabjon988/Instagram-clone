import React from 'react'
import '../styles-component/Header.css'
import { FiHome, FiSearch, FiHeart, FiPlusSquare } from 'react-icons/fi'
import { RiMessengerLine } from 'react-icons/ri'
import {VscAccount} from 'react-icons/vsc'
import {IoCompassOutline} from 'react-icons/io5'
import { NavLink } from 'react-router-dom'

function Header() {
    return (
        <div className="header">
            <div className="header__container">
                <div className="header__logo">
                    <img src="https://www.instagram.com/static/images/web/mobile_nav_type_logo.png/735145cfe0a4.pngloo" alt="logo" className="instagram__logo" />
                </div>
                <div className="header__search">
                    <div className="header__searchBar">
                        <FiSearch />
                        <input type="text" id="#" placeholder="Search" />
                    </div>
                </div>
                <ul className="header__collection">
                    <li className="header__item">
                    <NavLink to="/" ><FiHome /></NavLink></li>
                    <li className="header__item"><NavLink to="/" >
                    <RiMessengerLine /></NavLink></li>
                    <li className="header__item"><NavLink to="/"><FiPlusSquare /></NavLink></li>
                    <li className="header__item"><NavLink to="/"><IoCompassOutline /></NavLink></li>
                    <li className="header__item"><NavLink to="/"><FiHeart /></NavLink></li>
                    <li className="header__item"><NavLink to="/"><VscAccount /></NavLink></li>
                </ul>
            </div>
        </div>
    )
}

export default Header
